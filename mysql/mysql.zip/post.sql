/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : login

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2021-04-29 13:10:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `post`
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `label` varchar(50) DEFAULT NULL,
  `question` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES ('1', 'Java', 'NullPointerException是什么意思？');
INSERT INTO `post` VALUES ('2', 'MySQL', '插入操作应该怎么写？');
INSERT INTO `post` VALUES ('3', 'java', 'Date怎么使用？');
INSERT INTO `post` VALUES ('9', 'java', 'ssm是什么框架');
INSERT INTO `post` VALUES ('61', 'java', '怎样安装JDK?');
INSERT INTO `post` VALUES ('66', 'java', 'Java有哪些就业方向？');
