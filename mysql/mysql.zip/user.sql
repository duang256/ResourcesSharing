/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : login

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2021-04-29 13:10:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `registerTime` varchar(50) NOT NULL,
  `centainFields` varchar(30) DEFAULT NULL,
  `sex` int(10) DEFAULT '0',
  `birthday` varchar(50) DEFAULT NULL,
  `root` int(10) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'yanyue', '888888', '2021-4-13', 'Java/C++/C', '1', '10-23', '1');
INSERT INTO `user` VALUES ('3', 'zhangsan', '666666', '2021-4-13', 'C', '1', '1-1', '0');
